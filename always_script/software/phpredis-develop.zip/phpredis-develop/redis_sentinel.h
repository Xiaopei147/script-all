#ifndef REDIS_SENTINEL_H
#define REDIS_SENTINEL_H

#include "sentinel_library.h"

#define PHP_REDIS_SENTINEL_VERSION "0.1"

extern const zend_function_entry *redis_sentinel_get_methods(void);

#endif /* REDIS_SENTINEL_H */
